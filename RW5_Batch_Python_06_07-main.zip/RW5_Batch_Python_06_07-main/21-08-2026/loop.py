# Python Control Flow

#1. While Loop

# A while loop runs as long as the condition is True.

# syntax

'''

while condition:
    # code block

'''

i = 1

while i <= 5:
    print(f"while : {i}")
    i += 1

# For Loop

# Used to Interate :

'''

ranges
lists
strings
tuples
dictionaries

'''

# syntax

'''

for varibale in sequence:
    # code block

'''

# range(start , stop , step)

for i in range(0 , 5):
    print(f"for loop : {i}")

for i in range(1 , 6):
    print(f"for loop : {i}")

name = "Python"

for ch in name:
    print(ch)

fruits = ["Apple" , "Banana" , "Mango" , "Orange"]
num = [1 , 2 , 3 , 4 , 5]

print(fruits[0])
print(fruits[1])

for fruit in fruits:
    print(fruit)

for number in num:
    print(number * 10)
    




