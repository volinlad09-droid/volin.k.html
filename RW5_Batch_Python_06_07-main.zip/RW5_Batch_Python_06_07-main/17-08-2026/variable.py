# Python Variables , DataTypes and Operators

# Variable assignment

x = 5            # Integer
y = "Hello"  # string
z = 3.14        # float

# Variable Naming Rules

# Must start with a letter or underscore
# Cannot start with number
# Can only contain alpha-numeric characters and userscores

_x = 20

firstName = "rahul"

FirstName = "Priya"
first_name = "Kayra"

# Data-Types

'''

int : (3 , -5 , 100)
float : (3.14 , -0.00001)
complex:(3+5j)
bool:True or False
str:("hello" , "world")

'''

# Checking Data Types

# type(x)
# isinstance(x , int)

print(type(x))
print(isinstance(x , float))

# Operators

# Arithmetic Operator
# Assignment operator
# Comparision Operator
# Logical Operator
# Bitwise Operator

# Arithmetic Operator

print("Addition:" , x + z)
print("Substraction:" , x - z)
print("multiplication:" , x * z)
print("division:" , x / z)
print("modulus:" , x % z)
print("floor division" , x // z)
print("Expontiations:" , x ** x)

# Assignment operators

opr1 = 4
opr2 = 2

opr1 += opr2 # opr1 = opr1 + opr2

print(opr1)

opr1 -= opr2

print(opr1)

opr1 *= opr2

print(opr1)

opr1 /= opr2

print(opr1)

opr1 %= opr2

print(opr1)

opr1 **= opr2

print(opr1)




