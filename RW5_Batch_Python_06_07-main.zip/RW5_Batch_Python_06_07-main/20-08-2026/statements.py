# Python Control Flow

# Control flow mean the order in which Python executes
# the statement of a Program.

#1. Make decisions
#2. Repeat statements
#3. Change the normal execution order of a program

# 1. Conditional Statements / Decision Making Statements
# 2. Looping / Iteration
# 3. Jump / Transfer Statements

# 1. if Statement
# 2. if...else Statement
# 3. if...elif...else Statement
# 4. Nested if Statement
# 5. match-case Statement (Python 3.10) ( Switch Case)

'''
print("=== if Satatement =====")

age = 17

if age >= 18:
    print("You are eligible to vote")

'''

'''
print("===== if...else  Statement ======")

age = 18

if age >= 18:
    print("You are eligible to vote")
else:
    print("You are not eligible to vote")
'''
'''
print("======== if...elif..else  Statement =======")

marks = 50

if marks >= 90:
    print("Grade A")
elif marks >= 80:
    print("Grade B")
elif marks >= 70:
    print("Grade C")
elif marks >= 60:
    print("Grade D")
else:
    print("Fail")
'''
print("====== Nested Statement ======")

age = 17
_id = True

if age >= 18:
    print("Age is valid")

    if _id:
        print("ID is available.")
        print("Entry allowed.")
    else:
        print("ID is not available.")

else:
    print("Age is not valid.")


# match-case Statement

# Syntax
'''
match variable:
    case value1:
        #code
    case value2:
        #code
    case _:
        # default code 
'''

num1 = 10
num2 = 5
operator = "**"

match operator:

    case "+":
        print("Addition = " , num1 + num2)

    case "-":
        print("Subtraction = " , num1 - num2)

    case "*":
        print("Multiplication = " , num1 * num2)

    case "/":
        print("Division = " , num1 / num2)

    case _:
        print("Invalid Operator")

# Multiple Values in One Case

char = "ab"

match char:

    case "a" | "e" | "i" | "o" | "u":
        print("Vowel")

    case _:
        print("Consonant")



