# Comparision Operators

print("Comparision Operators")

a = 10
b = 10

print("01.  == Equal :" , a == b)
print("02. != Not Equal : " , a != b)
print("03. > Greater Than : " , a > b)
print("04. < Less Than : " , a < b)
print("05. <= Less/Equal : " , a <= b)
print("06. >= Greater/Equal : " ,  a >= b)


# Logical Operator

print("Logical Operator")

a = True
b = False
c = False

print("01. and Logical AND  : " , a and b)
print("02. or Logical OR : " , a or b)
print("03. not Logical NOT : " , not b)

print((10 > 12 or 20 <= 20) and (10 > 20 or 40 > 25))

# Bitwise Operator


a = 5
b = 3

print("& Bitwise AND : " , a & b)
print("| Bitwise OR : " , a | b)
print("^ Bitwise XOR : " , a ^ b)
print("~ Bitwise NOT : " , ~b)
print(" << Left Shift :" , a << 1)
print(">> Right Shift : " , a >> 1)

# Conditional / Ternary Operator

age = 17

result = 'ADULT' if age >= 18 else 'MINOR'

print(result)

# Operator Precedence

result = 10 + 5 * 2

print(result)

# Type Conversion

# id()

a = 20
b = 21

print(id(a))
print(id(b))


# Identity Operator


a = [1 , 2 , 3]
b = a
c = [1 , 2 , 3]

print(a is b)
print(a is c)
print(a is not c)

# membership operator

numbers = [1 ,  2 , 3 , 4 , 5]

print(20 in numbers)
print(2 in numbers)
print(20 not in numbers)
















